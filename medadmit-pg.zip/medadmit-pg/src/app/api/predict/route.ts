import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { classifyChance, predictAirFromMarks } from "@/lib/predictor";
import { predictorInputSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    const body = predictorInputSchema.parse(await req.json());

    let air = body.air ?? 0;
    let rankPrediction = null;

    if (body.mode === "marks") {
      const curves = await prisma.marksVsRankHistory.findMany({
        orderBy: [{ year: "desc" }, { score: "asc" }]
      });
      rankPrediction = predictAirFromMarks(body.marks!, curves);
      air = rankPrediction.midpoint;
    }

    const cutoffs = await prisma.cutoff.findMany({
      where: {
        category: body.category,
        quota: body.quota,
        ...(body.states.length ? { college: { state: { in: body.states } } } : {}),
        ...(body.collegeTypes.length ? { college: { collegeType: { in: body.collegeTypes } } } : {}),
        ...(body.branchIds.length ? { branchId: { in: body.branchIds } } : {}),
        ...(body.maxFee != null ? { feePerAnnum: { lte: body.maxFee } } : {})
      },
      include: { college: true, branch: true },
      orderBy: [{ year: "desc" }, { closingRank: "asc" }],
      take: 250
    });

    const latestByPair = new Map<string, typeof cutoffs[number]>();
    for (const c of cutoffs) {
      const key = `${c.collegeId}:${c.branchId}`;
      if (!latestByPair.has(key)) latestByPair.set(key, c);
    }

    const results = [...latestByPair.values()]
      .map(c => ({
        id: c.id,
        college: c.college.name,
        state: c.college.state,
        collegeType: c.college.collegeType,
        branch: c.branch.name,
        branchType: c.branch.type,
        closingRank: c.closingRank,
        openingRank: c.openingRank,
        feePerAnnum: Number(c.feePerAnnum),
        stipendYear1: c.college.stipendYear1 ? Number(c.college.stipendYear1) : null,
        bondYears: c.college.bondYears,
        bondPenaltyInr: c.college.bondPenaltyInr ? Number(c.college.bondPenaltyInr) : null,
        chance: classifyChance(air, c.closingRank)
      }))
      .sort((a, b) => {
        const order = { SAFE: 0, MODERATE: 1, DREAM: 2 };
        return order[a.chance] - order[b.chance] || a.closingRank - b.closingRank;
      })
      .slice(0, 80);

    return NextResponse.json({ air, rankPrediction, results });
  } catch (error) {
    return NextResponse.json({ error: "Invalid predictor request." }, { status: 400 });
  }
}
