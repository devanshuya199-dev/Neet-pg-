import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "MedAdmit PG — NEET PG Counseling & Seat Predictor",
  description: "Historical counseling trend explorer and NEET PG seat prediction portal."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
