"use client";

import { useMemo, useState } from "react";
import { Search, SlidersHorizontal, Stethoscope, ArrowRight, ShieldCheck, BarChart3 } from "lucide-react";
import { ResultCard } from "@/components/ResultCard";
import { predictAirFromMarks } from "@/lib/predictor";

const demoCurves = [
  { year: 2026, score: 450, airMin: 60000, airMax: 128000 },
  { year: 2026, score: 500, airMin: 20000, airMax: 52000 },
  { year: 2026, score: 550, airMin: 6800, airMax: 17500 },
  { year: 2026, score: 600, airMin: 1400, airMax: 4800 },
  { year: 2026, score: 650, airMin: 140, airMax: 700 },
  { year: 2025, score: 450, airMin: 62000, airMax: 130000 },
  { year: 2025, score: 500, airMin: 21000, airMax: 54000 },
  { year: 2025, score: 550, airMin: 7000, airMax: 18000 },
  { year: 2025, score: 600, airMin: 1500, airMax: 5000 },
  { year: 2025, score: 650, airMin: 150, airMax: 750 },
  { year: 2024, score: 450, airMin: 65000, airMax: 135000 },
  { year: 2024, score: 500, airMin: 23000, airMax: 57000 },
  { year: 2024, score: 550, airMin: 7500, airMax: 19000 },
  { year: 2024, score: 600, airMin: 1600, airMax: 5500 },
  { year: 2024, score: 650, airMin: 180, airMax: 800 },
  { year: 2023, score: 450, airMin: 70000, airMax: 140000 },
  { year: 2023, score: 500, airMin: 25000, airMax: 60000 },
  { year: 2023, score: 550, airMin: 8000, airMax: 20000 },
  { year: 2023, score: 600, airMin: 1800, airMax: 6000 },
  { year: 2023, score: 650, airMin: 200, airMax: 900 }
];

const mockResults = [
  { college:"MAMC Delhi", state:"Delhi", collegeType:"Govt", branch:"MD General Medicine", closingRank:650, openingRank:40, feePerAnnum:150000, stipendYear1:125000, bondYears:1, bondPenaltyInr:1500000, chance:"DREAM" as const },
  { college:"KGMU Lucknow", state:"Uttar Pradesh", collegeType:"Govt", branch:"MD Dermatology", closingRank:1200, openingRank:400, feePerAnnum:150000, stipendYear1:105000, bondYears:2, bondPenaltyInr:1000000, chance:"MODERATE" as const },
  { college:"SMS Medical College", state:"Rajasthan", collegeType:"Govt", branch:"MD Radio-Diagnosis", closingRank:1800, openingRank:700, feePerAnnum:150000, stipendYear1:100000, bondYears:2, bondPenaltyInr:1200000, chance:"MODERATE" as const },
  { college:"Kasturba Medical College, Manipal", state:"Karnataka", collegeType:"Deemed", branch:"MD General Medicine", closingRank:11000, openingRank:6000, feePerAnnum:6500000, stipendYear1:90000, bondYears:0, bondPenaltyInr:0, chance:"SAFE" as const }
];

export default function Home() {
  const [mode, setMode] = useState<"marks" | "rank">("marks");
  const [marks, setMarks] = useState("560");
  const [air, setAir] = useState("");
  const [category, setCategory] = useState("UR");
  const [quota, setQuota] = useState("AIQ");
  const [showFilters, setShowFilters] = useState(false);
  const [results, setResults] = useState(mockResults);

  const prediction = useMemo(() => {
    if (mode !== "marks" || !marks) return null;
    return predictAirFromMarks(Number(marks), demoCurves);
  }, [marks, mode]);

  function runPrediction() {
    if (mode === "rank") {
      const rank = Number(air);
      setResults(mockResults.map(x => ({
        ...x,
        chance: rank && x.closingRank > rank * 1.15 ? "SAFE" : rank && x.closingRank >= rank * 0.85 ? "MODERATE" : "DREAM"
      })));
    } else if (prediction) {
      setAir(String(prediction.midpoint));
    }
  }

  return (
    <main className="min-h-screen">
      <nav className="border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-teal-600 text-white"><Stethoscope size={22}/></div>
            <div><div className="font-extrabold tracking-tight">MedAdmit <span className="text-teal-600">PG</span></div><div className="text-xs text-slate-500">NEET PG Counseling Intelligence</div></div>
          </div>
          <div className="hidden gap-6 text-sm font-medium text-slate-600 md:flex"><a href="#predictor">Predictor</a><a href="#results">Results</a><a href="#methodology">Methodology</a></div>
        </div>
      </nav>

      <section className="bg-gradient-to-b from-teal-50 to-slate-50">
        <div className="mx-auto max-w-7xl px-4 pb-14 pt-14 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mx-auto mb-5 flex w-fit items-center gap-2 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-teal-700 shadow-sm ring-1 ring-teal-100"><ShieldCheck size={15}/> Data-driven counseling planning</div>
            <h1 className="text-4xl font-black tracking-tight text-slate-900 sm:text-6xl">Find your probable <span className="text-teal-600">NEET PG seat.</span></h1>
            <p className="mt-5 text-base leading-7 text-slate-600 sm:text-lg">Estimate AIR from marks and explore college–branch combinations using historical round-wise closing ranks.</p>
          </div>

          <div id="predictor" className="mx-auto mt-10 max-w-5xl rounded-3xl border border-slate-200 bg-white p-4 shadow-soft sm:p-6">
            <div className="flex rounded-xl bg-slate-100 p-1">
              {(["marks","rank"] as const).map(m => <button key={m} onClick={() => setMode(m)} className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-bold ${mode===m ? "bg-white text-teal-700 shadow-sm" : "text-slate-500"}`}>{m === "marks" ? "Predict by Marks" : "Predict by Rank"}</button>)}
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              <label className="md:col-span-2"><span className="mb-1.5 block text-xs font-semibold text-slate-600">{mode === "marks" ? "NEET PG Marks" : "Official AIR"}</span>
                <input value={mode === "marks" ? marks : air} onChange={e => mode==="marks" ? setMarks(e.target.value) : setAir(e.target.value)} type="number" placeholder={mode==="marks" ? "e.g. 560" : "e.g. 4200"} className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none ring-teal-500 focus:ring-2"/>
              </label>
              <label><span className="mb-1.5 block text-xs font-semibold text-slate-600">Category</span><select value={category} onChange={e=>setCategory(e.target.value)} className="w-full rounded-xl border border-slate-300 px-4 py-3"><option>UR</option><option>OBC</option><option>EWS</option><option>SC</option><option>ST</option><option>PwD</option></select></label>
              <label><span className="mb-1.5 block text-xs font-semibold text-slate-600">Domicile</span><select className="w-full rounded-xl border border-slate-300 px-4 py-3"><option>Punjab</option><option>Delhi</option><option>Uttar Pradesh</option><option>Maharashtra</option><option>Rajasthan</option><option>Karnataka</option></select></label>
              <label><span className="mb-1.5 block text-xs font-semibold text-slate-600">Preferred quota</span><select value={quota} onChange={e=>setQuota(e.target.value)} className="w-full rounded-xl border border-slate-300 px-4 py-3"><option value="AIQ">AIQ 50%</option><option value="State_Quota">State Quota</option><option value="Management">Management</option><option value="DNB">DNB</option><option value="Central">Central University</option></select></label>
              <button onClick={() => setShowFilters(v=>!v)} className="mt-5 flex items-center justify-center gap-2 rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold text-slate-700"><SlidersHorizontal size={17}/> Advanced filters</button>
            </div>
            {showFilters && <div className="mt-4 grid gap-4 rounded-2xl bg-slate-50 p-4 md:grid-cols-3"><label className="text-sm"><span className="block text-xs font-semibold text-slate-500">Target branch</span><select className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2.5"><option>Any branch</option><option>MD Dermatology</option><option>MD Radio-Diagnosis</option><option>MD General Medicine</option><option>MS General Surgery</option><option>MD OBGY</option></select></label><label className="text-sm"><span className="block text-xs font-semibold text-slate-500">Target state</span><select className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2.5"><option>All India</option><option>Delhi</option><option>Punjab</option><option>Rajasthan</option><option>Karnataka</option></select></label><label className="text-sm"><span className="block text-xs font-semibold text-slate-500">Max annual fee</span><input type="range" min="100000" max="8000000" step="100000" className="mt-4 w-full"/></label></div>}
            <div className="mt-5 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>{prediction && mode==="marks" && <div><div className="text-xs font-semibold uppercase tracking-wide text-slate-400">Estimated AIR range</div><div className="text-2xl font-black text-slate-900">{prediction.airMin.toLocaleString()} – {prediction.airMax.toLocaleString()}</div><div className="text-xs text-slate-500">Confidence {Math.round(prediction.confidence)}%</div></div>}</div>
              <button onClick={runPrediction} className="inline-flex items-center justify-center gap-2 rounded-xl bg-teal-600 px-6 py-3 font-bold text-white shadow-lg shadow-teal-600/20 hover:bg-teal-700">Predict seats <ArrowRight size={18}/></button>
            </div>
          </div>
        </div>
      </section>

      <section id="results" className="mx-auto max-w-7xl px-4 py-12 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-[250px_1fr]">
          <aside className="hidden h-fit rounded-2xl border border-slate-200 bg-white p-5 lg:block">
            <div className="flex items-center gap-2 font-bold"><SlidersHorizontal size={17}/> Filters</div>
            <div className="mt-5 space-y-5 text-sm"><Filter title="State"><span>All India</span></Filter><Filter title="College type"><span>Govt · Central · Deemed</span></Filter><Filter title="Branch"><span>Medicine · Radio · Derma</span></Filter><Filter title="Year"><span>2025</span></Filter></div>
          </aside>
          <div>
            <div className="mb-5 flex items-end justify-between"><div><p className="text-sm font-semibold text-teal-700">PREDICTED OPTIONS</p><h2 className="text-2xl font-black">College & branch matches</h2></div><button className="hidden items-center gap-2 rounded-lg border px-3 py-2 text-sm md:flex"><Search size={15}/> Search directory</button></div>
            <div className="grid gap-4">{results.map((r,i)=><ResultCard key={i} result={r}/>)}</div>
          </div>
        </div>
      </section>

      <section id="methodology" className="border-y border-slate-200 bg-white">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-12 md:grid-cols-3 lg:px-8">
          <Info icon={<BarChart3/>} title="Historical curves" text="Uses year-weighted marks-to-AIR interpolation with uncertainty bands."/>
          <Info icon={<ShieldCheck/>} title="Round-wise cutoffs" text="Compares candidate AIR against R1, R2, R3 and Stray/Mop-Up closing ranks."/>
          <Info icon={<Stethoscope/>} title="Counselling context" text="Quota, category, domicile, college type and fee constraints are modeled independently."/>
        </div>
      </section>
      <footer className="bg-slate-950 px-4 py-8 text-center text-xs text-slate-400">MedAdmit PG · Planning tool only. Historical/mock data must be verified against current official counselling notices before decisions.</footer>
    </main>
  );
}

function Filter({ title, children }: { title: string; children: React.ReactNode }) { return <div><div className="text-xs font-semibold uppercase tracking-wide text-slate-400">{title}</div><div className="mt-2 rounded-lg bg-slate-50 p-2.5 text-slate-700">{children}</div></div>; }
function Info({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) { return <div className="rounded-2xl border border-slate-200 p-5"><div className="mb-3 text-teal-600">{icon}</div><h3 className="font-bold">{title}</h3><p className="mt-1 text-sm leading-6 text-slate-500">{text}</p></div>; }
